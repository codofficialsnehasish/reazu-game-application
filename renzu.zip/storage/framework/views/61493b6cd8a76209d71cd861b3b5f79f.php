<?php echo $__env->make('frontend.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="bg-gradient-to-br from-yellow-600 via-orange-700 to-pink-700 text-white">

    <!-- NAVBAR -->
    <?php echo $__env->make('frontend.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- PROFILE SECTION -->
    <section id="profile" class="container mx-auto px-6 py-14">

        <h1 class="text-4xl font-extrabold mb-8 text-center">My Profile</h1>

        <div class="glass p-8 rounded-2xl max-w-lg mx-auto text-white/90">

            <?php if(session('success')): ?>
                <div class="mb-4 p-3 bg-green-500/50 rounded-lg text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- USER DETAILS -->
            <form action="<?php echo e(route('user.profile.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Name -->
                <label class="block mb-2 text-sm font-semibold">Full Name</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>" required
                       class="w-full mb-4 px-4 py-3 rounded-lg bg-white/10 border border-white/20 
                              focus:outline-none focus:ring-2 focus:ring-yellow-300 text-white">

                <!-- Phone -->
                <label class="block mb-2 text-sm font-semibold">Phone Number</label>
                <input type="text" name="phone" value="<?php echo e($user->phone); ?>" required
                       class="w-full mb-6 px-4 py-3 rounded-lg bg-white/10 border border-white/20 
                              focus:outline-none focus:ring-2 focus:ring-yellow-300 text-white">

                <!-- Update Button -->
                <button type="submit"
                        class="w-full py-3 rounded-lg bg-yellow-400 text-black font-bold text-lg 
                               hover:bg-yellow-300 transition">
                    Update Profile
                </button>
            </form>

            <!-- Logout -->
            <form action="<?php echo e(route('user.logout')); ?>" method="POST" class="mt-6">
                <?php echo csrf_field(); ?>
                <button type="submit"
                        class="w-full py-3 rounded-lg bg-blue-500/80 text-white font-bold text-lg 
                               hover:bg-blue-400 transition">
                    Logout
                </button>
            </form>

            <!-- Delete Account -->
            <form action="<?php echo e(route('user.delete')); ?>" method="POST"
                  class="mt-4"
                  onsubmit="return confirm('Are you sure you want to delete your account permanently?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit"
                        class="w-full py-3 rounded-lg bg-red-500/80 text-white font-bold text-lg 
                               hover:bg-red-400 transition">
                    Delete Account
                </button>
            </form>

        </div>
    </section>

    <!-- FOOTER -->
    <footer class="py-10 text-center text-white/80">
        © 2025 Renzu Games. All Rights Reserved.
    </footer>

</body>

</html>
<?php /**PATH C:\wamp64\www\renzu\resources\views/user/profile.blade.php ENDPATH**/ ?>