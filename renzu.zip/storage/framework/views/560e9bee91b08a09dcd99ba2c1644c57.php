<header class="py-4">
    <div class="container mx-auto px-6 flex items-center justify-between">
      <div class="flex items-center gap-3 logo_warp">
        <img src="<?php echo e(asset('image/logo.png')); ?>" class="w-16 drop-shadow-xl" alt="Renzu Logo">
      </div>

      <nav class="hidden md:flex gap-6 text-white/90 font-medium">
        <a href="<?php echo e(route('home')); ?>" class="hover:text-yellow-300">Home</a>
        <a href="<?php echo e(route('terms')); ?>" class="hover:text-yellow-300">Terms</a>
        <a href="<?php echo e(route('privacy')); ?>" class="hover:text-yellow-300">Privacy</a>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('user.logout')); ?>" 
              onclick="event.preventDefault(); document.getElementById('logout-form').submit();" 
              class="hover:text-yellow-300">
                Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('user.logout')); ?>" method="POST" class="hidden">
                <?php echo csrf_field(); ?>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('user.login')); ?>" class="hover:text-yellow-300">Login</a>
        <?php endif; ?>

      </nav>
    </div>
  </header><?php /**PATH C:\wamp64\www\renzu\resources\views/frontend/navbar.blade.php ENDPATH**/ ?>