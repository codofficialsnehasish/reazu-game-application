<?php echo $__env->make('frontend.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body class="bg-gradient-to-br from-yellow-600 via-orange-700 to-pink-700 text-white">

    <!-- NAVBAR -->
    <?php echo $__env->make('frontend.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- LOGIN SECTION -->
    <section id="login" class="container mx-auto px-6 py-14">

        <h1 class="text-4xl font-extrabold mb-8 text-center">Login</h1>

        <div class="glass p-8 rounded-2xl max-w-md mx-auto text-white/90">

            <?php if($errors->any()): ?>
                <div class="mb-4 p-3 bg-red-500/50 rounded-lg">
                    <ul class="list-disc list-inside text-sm">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="mb-4 p-3 bg-green-500/50 rounded-lg text-sm">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('user.login.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Phone -->
                <label class="block mb-2 text-sm font-semibold">Phone Number</label>
                <input type="text" name="phone" required
                       class="w-full mb-4 px-4 py-3 rounded-lg bg-white/10 border border-white/20 
                              focus:outline-none focus:ring-2 focus:ring-yellow-300 text-white">

                <!-- Password -->
                <label class="block mb-2 text-sm font-semibold">Password</label>
                <input type="password" name="password" required
                       class="w-full mb-6 px-4 py-3 rounded-lg bg-white/10 border border-white/20 
                              focus:outline-none focus:ring-2 focus:ring-yellow-300 text-white">

                <button type="submit"
                        class="w-full py-3 rounded-lg bg-yellow-400 text-black font-bold text-lg 
                               hover:bg-yellow-300 transition">
                    Login
                </button>
            </form>
        </div>

        

    </section>

    <!-- FOOTER -->
    <footer class="py-10 text-center text-white/80">
        © 2025 Renzu Games. All Rights Reserved.
    </footer>

</body>

</html>
<?php /**PATH C:\wamp64\www\renzu\resources\views/user/login.blade.php ENDPATH**/ ?>